int which_child(const char * arvb_filename, BNode * child){
	int i;
	int my_relative_idx = -1;
	Bnode * parent = read_from_file(arvb_filename, child->father_offset);
	for(i = 0; i < parent->ocup + 1; i++){
		if(child->itself_offset == parent->children_offset[i]) my_relative_idx = i;
	}
	free(parent);
	return my_relative_idx;
}

int left_to_right(const char * arvb_filename, BNode * middle){
	int i;
	int brother_idx = -1;
	int middle_idx = which_child(arvb_filename, middle);
	BNode * parent = read_from_file(arvb_filename, middle->father_offset);
	BNode * right_brother = NULL;
	if(middle_idx < parent->ocup - 1){
		right_brother = read_from_file(arvb_filename, parent->children_offset[middle_idx+1]);
		if(right_brother->ocup < N_ELEMENTS) brother_idx = middle_idx+1;
		free(right_brother);
	}
	free(parent);
	return brother_idx;
}

int right_to_left(const char * arvb_filename, BNode * middle){
	int i;
	int brother_idx = -1;
	int middle_idx = which_child(arvb_filename, middle);
	BNode * parent = read_from_file(arvb_filename, middle->father_offset);
	BNode * left_brother = NULL;
	if(middle_idx > 0){
		left_brother = read_from_file(arvb_filename, parent->children[middle_idx - 1]);
		if(left_brother->ocup < N_ELEMENTS) brother_idx = middle_idx - 1;
		free(left_brother);
	}
	free(parent);
	return brother_idx;
}

int which_idx_to_redistribute(const char * arvb_filename, BNode * middle){
	int lr = left_to_right(arvb_filename, middle);
	if(lr != -1) return lr;
	int rl = right_to_left(arvb_filename, middle);
	return rl;
}
